module.exports.ex1 = function(req, res){
    const milli = Date.now();
    const dateEx1 = {
        milliseconds: milli
    };

    let date = new Date();
    dateEx1['dateFormat1'] = date.getDate()+"-"+(date.getMonth()+ 1)+"-"+date.getFullYear();
    dateEx1['dateFormat2'] = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();

    res.send(dateEx1);
}

module.exports.ex2 = function(req, res){
    const op = {};

    for (let index = 2; index <= 5; index++) {
        for (let k = 1; k < 10; k++) {
            op[`${index} x ${k}`] = (index*k);
        }
    }

    res.send(op);
}

module.exports.ex3 = function(req, res){
    let n = req.query.n;

    const op = {};

    var total = 1; 
	for (i=1; i<=n; i++) {
        total = total * i; 
	}

    op[`Factorial de ${n}`] = total;

    res.send(op);
}

module.exports.ex4 = function(req, res){
    const json = {};

    let operacion = req.query.op;
    let param1 = req.body.param1;
    let param2 = req.body.param2;

    switch (operacion) {
        case 'multiplicacion':
            json[`${param1} x ${param2}`] = param1*param2;
            break;
        case 'suma':
            json[`${param1} + ${param2}`] = param1+param2;
            break;
        case 'resta':
            json[`${param1} - ${param2}`] = param1-param2;
            break;
        case 'division':
            if (param2 == 0) {
                res.status(422).send("0 no aceptado");
            } else {
                json[`${param1} / ${param2}`] = param1/param2;
            }
            break;
    }

    res.send(json);
}
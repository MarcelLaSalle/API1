const express = require('express');
const router = express.Router();

const controller = require('../controller/exRoutes.js');

router.get('/1', controller.ex1);
router.get('/2', controller.ex2);
router.get('/3', controller.ex3);
router.get('/4', controller.ex4);

module.exports = router;
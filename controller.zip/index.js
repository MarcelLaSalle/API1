const express = require('express');
const app = express();

app.use(express.json());

const myController = require('./controller/myController.js');

//req: request res: response
app.get('/', myController.get);

app.use('/api/v1/example', require('./routes/exRoutes.js'));

app.listen(3000, function(){
    console.log('Server running');
});